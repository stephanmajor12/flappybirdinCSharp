﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

/// <summary>
/// Author: Stephan Major.
/// A recreation of flappybird the game.
/// </summary>

namespace flappyBirdGame
{
    public partial class FlappyBird : Form
    {
        private int pipeSpeed = 20;
        private int gravity = 50;
        private int currentScore = 0;

        public FlappyBird(int totalScore, string username)
        {
            InitializeComponent();
            label2.Text = totalScore.ToString();
            label4.Text = username;
            label5.Text = "Your total score overall is:" + totalScore;
        }

        private void gameTimerEvent(object sender, EventArgs e)
        {
            theBird.Top += gravity;
            pipeBottem.Left -= pipeSpeed;
            pipeTop.Left -= pipeSpeed;
            label1.Text = "Score: " + currentScore;

            if (pipeBottem.Left < -50)
            {
                pipeBottem.Left = 800;
                currentScore++;
            }
            if (pipeTop.Left < -80)
            {
                pipeTop.Left = 950;
                currentScore++;
            }
            if (theBird.Bounds.IntersectsWith(pipeBottem.Bounds)
                || theBird.Bounds.IntersectsWith(pipeTop.Bounds)
                || theBird.Bounds.IntersectsWith(ground.Bounds))
            {
                endGame();
            }
            if (currentScore > 5)
            {
                pipeSpeed = 30;
            }
            if (theBird.Top < -25)
            {
                endGame();
            }
        }

        private void endGame()
        {
            gameTimer.Stop();

            label1.Text = "Game Over. Your Score was: " + currentScore;
            string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=csharpApp;Integrated Security=True";

            using (SqlConnection conn = new SqlConnection(connectionString)) //connects to the database.
            {
                conn.Open(); //Opens connection.
                using (SqlCommand command = new SqlCommand($"UPDATE dbo.users SET Score='{currentScore + Convert.ToInt32(label2.Text)}' WHERE Username='{label4.Text}'", conn))//Checks which query to run.
                {
                    using (SqlDataReader reader = command.ExecuteReader())//Runs the command.
                    {
                    }
                }
            }
        }

        private void gameKeyIsDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = -30;
            }
        }

        private void gameKeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space)
            {
                gravity = 30;
            }
        }

        private void FlappyBird_Load(object sender, EventArgs e)
        {
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
        }

        private void ground_Click(object sender, EventArgs e)
        {
        }
    }
}