﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/// <summary>
/// Author: Stephan Major.
/// A simple login program before you can play your game!
/// </summary>

namespace flappyBirdGame
{

    public partial class Form1 : Form
    {
        private static void query(List<String> listFiller, String[] querys, string connectionString, int number)
        {
            using (SqlConnection conn = new SqlConnection(connectionString)) //connects to the database.
            {
                conn.Open(); //Opens connection.
                using (SqlCommand command = new SqlCommand(querys[number], conn))//Checks which query to run.
                {
                    using (SqlDataReader reader = command.ExecuteReader())//Runs the command.
                    {
                        while (reader.Read())//While reading.
                        {
                            if (number == 2)//If query 2.
                            {
                                listFiller.Add(reader.GetInt64(0).ToString());//Int to string.
                            }
                            else //Else just put it to a string.
                            {
                                listFiller.Add(reader.GetString(0));
                            }
                        }
                    }
                }
            }
        }



        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] querys1 = { "SELECT Username FROM dbo.users", "SELECT Password FROM dbo.users", "SELECT Score FROM dbo.users" };

            string connectionString = @"Data Source=.\SQLEXPRESS;Initial Catalog=csharpApp;Integrated Security=True";

            List<String> myUser = new List<String>();
            List<String> myPass = new List<String>();
            List<String> myScore = new List<String>();

            query(myUser, querys1, connectionString, 0);
            query(myPass, querys1, connectionString, 1);
            query(myScore, querys1, connectionString, 2);

            string userName = textBox1.Text;
            string userPass = textBox2.Text;

            string result1 = myUser.FirstOrDefault(x => x == userName);
            string result2 = myPass.FirstOrDefault(x => x == userPass);
            string result3 = myScore.FirstOrDefault(x => x == userName);

            if (result1 != null && result2 != null) {
                int someNum = 0;
                foreach(var i in myScore)
                {
                    someNum = Convert.ToInt32(i);
                }

                FlappyBird f = new FlappyBird(someNum,userName);
                f.Show();
            } else
            {
                label3.Text = "Invalid login name/pass.";
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
